let handler = async (m, { conn }) => {
conn.reply(m.chat, '_*On'*_' fkontak)
}
handler.command = ['bot']

export default handler
let handler = async (m) = {
m.reply('On')
{
handler.customPrefix = /^(bot|bot?|bott)$/i
handler.command = new RegExp

export default handler
let handler = async (m) => {
m.reply('Sc Bot : https://xnxx.com')
}
handler.command = ['sc2']

export default handler
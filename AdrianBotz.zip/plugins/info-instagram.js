let handler = async (m, { conn }) => {
let url = 'https://instagram.com/Arifzyn19_'
conn.reply(m.chat, '*▸ - - - —「 ƒσłłσω мε 」— - - - ◂*\n' + url, fkontak)
}
handler.command = ['ownig']

export default handler